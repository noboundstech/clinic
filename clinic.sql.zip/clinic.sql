-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2016 at 02:02 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `clinic`
--
CREATE DATABASE IF NOT EXISTS `clinic` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `clinic`;

-- --------------------------------------------------------

--
-- Table structure for table `auth_roles`
--

DROP TABLE IF EXISTS `auth_roles`;
CREATE TABLE IF NOT EXISTS `auth_roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `role_description` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=6 ;

--
-- Dumping data for table `auth_roles`
--

INSERT INTO `auth_roles` (`role_id`, `role_name`, `role_description`) VALUES
(1, 'Admin', 'Administrator of the application'),
(2, 'Staff', 'Staff of the organisation'),
(3, 'Doctor', 'Doctor of the hospital'),
(4, 'Technician', 'Technician of the lab'),
(5, 'Nurse', 'Nurse of the hospital');

-- --------------------------------------------------------

--
-- Table structure for table `auth_roles_permissions`
--

DROP TABLE IF EXISTS `auth_roles_permissions`;
CREATE TABLE IF NOT EXISTS `auth_roles_permissions` (
  `rp_role_id` int(3) NOT NULL,
  `rp_url_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_roles_permissions`
--

INSERT INTO `auth_roles_permissions` (`rp_role_id`, `rp_url_id`) VALUES
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(1, 8),
(1, 7),
(1, 9),
(1, 1),
(1, 2),
(1, 4),
(1, 3),
(1, 10),
(1, 5),
(1, 6),
(2, 1),
(2, 2),
(2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `auth_urls`
--

DROP TABLE IF EXISTS `auth_urls`;
CREATE TABLE IF NOT EXISTS `auth_urls` (
  `url_id` int(11) NOT NULL AUTO_INCREMENT,
  `url_name` varchar(200) NOT NULL,
  `url_description` varchar(200) NOT NULL,
  PRIMARY KEY (`url_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `auth_urls`
--

INSERT INTO `auth_urls` (`url_id`, `url_name`, `url_description`) VALUES
(1, 'auth/login', 'Login page'),
(2, 'auth/logout', 'Logout page'),
(3, 'auth/roles', 'User Role listing page'),
(4, 'auth/permissions', 'User Permission page'),
(5, 'user/dashboard', 'User Dashboard page'),
(6, 'user/index', 'Listing of all users'),
(7, 'auth/createrole', 'Create User Role'),
(8, 'auth/assignpermission', 'Assign Permission to User based on Role'),
(9, 'auth/createurl', 'Create a new URL for user access'),
(10, 'user/createuser', 'Create a new User');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(11) NOT NULL DEFAULT '1',
  `user_name` varchar(25) NOT NULL,
  `user_password` varchar(32) NOT NULL,
  `user_firstname` varchar(30) DEFAULT NULL,
  `user_lastname` varchar(30) DEFAULT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_mobile` varchar(10) NOT NULL,
  `user_is_active` smallint(1) NOT NULL DEFAULT '0',
  `user_last_ip` varchar(40) NOT NULL,
  `user_last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_role_id`, `user_name`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_mobile`, `user_is_active`, `user_last_ip`, `user_last_login`, `user_created`, `user_modified`) VALUES
(1, 1, 'admin', '88280c5391e6ea613ff7fb2c2e5db2c4', 'Sanjoy', 'Chowdhury', 'sanjoyc@aranaxweb.com', '9830799651', 1, '', '0000-00-00 00:00:00', '2016-12-12 00:00:00', '2016-12-20 08:20:37'),
(2, 2, 'johndoe', '88280c5391e6ea613ff7fb2c2e5db2c4', 'John', 'Doe', 'john@gmail.com', '9876543210', 0, '', '0000-00-00 00:00:00', '2016-12-23 13:48:03', '2016-12-23 11:15:47');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
